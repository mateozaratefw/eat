"use client"

import type { Product } from "@/types/product"
import { useCart } from "@/context/cart-context"
import { Check, Plus, Minus } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import { useState } from "react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  const { addToCart, removeFromCart, isInCart, getCartItemQuantity, updateQuantity } = useCart()
  const inCart = isInCart(product.id)
  const [quantity, setQuantity] = useState(getCartItemQuantity(product.id) || 1)

  const handleAddToCart = () => {
    if (inCart) {
      removeFromCart(product.id)
    } else {
      addToCart(product, quantity)
    }
  }

  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity > 0) {
      setQuantity(newQuantity)
      if (inCart) {
        updateQuantity(product.id, newQuantity)
      }
    }
  }

  return (
    <Card className={`overflow-hidden transition-all ${inCart ? "ring-2 ring-primary" : ""}`}>
      <CardContent className="p-0">
        <div className="relative aspect-square">
          <Image
            src={product.images[0] || "/placeholder.svg?height=300&width=300"}
            alt={product.name}
            fill
            className="object-cover"
          />
        </div>
        <div className="p-4">
          <h3 className="font-semibold">{product.name}</h3>
          <p className="text-sm text-muted-foreground line-clamp-2 h-10">{product.description}</p>
          <div className="mt-2 flex items-center justify-between">
            <span className="font-bold text-lg">${product.price.toLocaleString("es-AR")}</span>
            <span className="text-xs px-2 py-1 bg-secondary rounded-full">{product.category}</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex-col">
        <div className="flex items-center justify-between w-full mb-2">
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="icon"
              className="h-8 w-8"
              onClick={() => handleQuantityChange(quantity - 1)}
              disabled={quantity <= 1}
            >
              <Minus className="h-4 w-4" />
            </Button>
            <span className="w-8 text-center">{quantity}</span>
            <Button
              variant="outline"
              size="icon"
              className="h-8 w-8"
              onClick={() => handleQuantityChange(quantity + 1)}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <Button variant={inCart ? "secondary" : "default"} className="w-full" onClick={handleAddToCart}>
          {inCart ? (
            <>
              <Check className="mr-2 h-4 w-4" /> Seleccionado
            </>
          ) : (
            "Seleccionar"
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}

