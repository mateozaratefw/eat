"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import { SearchBar } from "@/components/search-bar"
import { ProductCard } from "@/components/product-card"
import { CartSummary } from "@/components/cart-summary"
import type { Product } from "@/types/product"

export default function Home() {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const searchParams = useSearchParams()
  const query = searchParams.get("query") || ""

  useEffect(() => {
    async function fetchProducts() {
      setLoading(true)
      try {
        const url = query ? `/api/products?query=${encodeURIComponent(query)}` : "/api/products"
        const response = await fetch(url)
        const data = await response.json()
        setProducts(data)
      } catch (error) {
        console.error("Error fetching products:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchProducts()
  }, [query])

  return (
    <main className="flex min-h-screen flex-col items-center py-8 px-4 pb-24">
      <div className="container max-w-7xl">
        <h1 className="text-3xl font-bold text-center mb-6">Productos disponibles</h1>
        <SearchBar />

        {loading ? (
          <div className="flex justify-center my-12">
            <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
          </div>
        ) : products.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="text-center my-12">
            <h2 className="text-xl font-semibold mb-2">No se encontraron productos</h2>
            <p className="text-muted-foreground">Intenta con otra búsqueda o explora todas las categorías.</p>
          </div>
        )}
      </div>
      <CartSummary />
    </main>
  )
}

